HUSTLE FORGE v0.4 - character mod maker for Your Only Move Is HUSTLE
=====================================================================

Run HustleForge.exe. No install needed.
New here? Press TUTORIAL in the top bar: "Basics" (10 min, your first mod) or
"Complete guide" (every feature). The same text is in TUTORIAL.txt.
 A new project starts from a stick-fighter
template that already has every base animation, 5 moves and a fireball, so you can export a
working mod right away and then change things.

TABS (F1-F8)
------------
1 CHARACTER  Name, mod folder, author, physics (gravity, air speed, air options),
             extra colours. Preview of your character-select card.

2 SPRITES    Pixel editor for all animations (128x128 frames, feet on the blue line).
             Tools: B pencil, E eraser, L line, R rect (Shift+R filled), O ellipse,
             G fill, I picker, M select/move pixels, V shift layer.
             Mirror drawing, dither brush, onion skin, grid, layers, frame strip,
             live preview, PNG / sprite-sheet import (horizontal strip of 128x128).
             Ctrl+Z / Ctrl+Y undo/redo, Ctrl+C / Ctrl+V copy/paste selection,
             H flip, X swap colours, [ ] brush size, , . previous/next frame.
             PURE WHITE pixels become the player's colour in game. Magenta / cyan
             become extra colours 2 / 3 if enabled. Any other colour stays as drawn.
             Grey names in the list = base animations you have not drawn yet
             (the game uses the default stickman for those). Click to create.

3 POSER      Make sprites WITHOUT drawing. A stick skeleton you pose by dragging its joints
             (IK bends elbows / knees for you, Shift = stretch a bone). Set a few key
             poses, the in-between frames are made automatically (smooth / ease in /
             ease out / hold, loop). Body shape sliders (height, limb & torso thickness,
             head size, arm / leg / torso / neck length, fists, feet), head shapes, eyes.
             42 accessories that follow the bones: hats, hair, masks, capes, scarves,
             wings, tails, swords, katana, axe, spear, scythe, staff, pistol, shield,
             claws, gloves, boots. Capes, scarves, hair and tails swing on their own.
             16 ready-made looks (Knight, Mage, Ninja, Vampire, Reaper, Demon...) and
             RANDOMIZE. Pose library (79 poses) and animation library (all 25 base
             animations + 33 attacks, weapon swings, casts, throws, taunts).
             "Rig ALL base animations" makes a whole character in one click.
             BAKE writes the frames into the animation's "Rig" layer (Sprites tab).
             Recolor... changes the colours of the whole character at once.

4 MOVES      Pick a preset (jab, launcher, low, overhead, dive, lunge, projectile,
             command grab, supers, armored counter) and edit it.
             Stage: drag hitboxes, drag handles to resize, right-click = new hitbox,
             yellow arrow = knockback direction, grey dummy = reach check.
             Timeline: drag hitbox bars to change start/active ticks; click the Armor
             or Invuln rows to add ranges; Sound / Push markers are draggable.
             Frame data is computed live. ON BLOCK uses the game's plus_frames rule.
             COMBO CHECK tells you if move A combos into move B (cancel or link).
             "Combos & cancels" checkboxes decide what each move can cancel into on hit.
             Effects: schedule any effect on a tick; Hit spark: effect on impact.
             Projectiles: spawn a projectile on a tick, from an offset. Its flight is
             previewed right on the stage while you scrub the timeline.
             Teleport: on a tick, jump to a spot relative to the opponent, yourself,
             your newest projectile, the stage, or a wall. Options: face the
             opponent, stop momentum, remove the projectile, flash effect.
             Presets "Teleport behind" and "Warp to projectile" show both.

5 PROJECTILES  Templates: fireball, kunai, bomb (arcs + bounces), homing orb,
             aimed bolt (fires at the opponent), drill (slow multi-hit).
             Looks: a Sprites-tab animation (centre of the frame = projectile)
             or a glowing effect. Flight: speed, angle, gravity, homing, lifetime.
             Collisions: number of hits, hit spacing, vanish / bounce / slide on
             the ground, walls, hurtbox, clashing. Trail and vanish effects.
             Hitboxes are edited like move hitboxes. The flight preview shows the
             whole path and tells you if it reaches an opponent N px away.

6 EFFECTS    Layered glowing effects: slash, streak, arc, ring, pillar, ground thorns,
             speed lines, particle bursts, flash. Templates to start from.
             Effects are drawn additively in game: black = transparent.
             They are baked into sprite sheets automatically when you export.

7 MECHANICS  Resources (custom gauges), statuses (stacks on the opponent that hurt
             them when they act), and WHEN / IF / DO rules. Recipes give you ready
             mechanics (bleed, rage, lifesteal, blood price, combo bonus, momentum).
             Resource display: Bar, Cells (one square per point - spell slots,
             charges; up to 12), Number ("MANA 2/3") or Hidden, shown above the
             character or in the HUD under the health bar. "Every N ticks" lets a
             resource refill slowly (e.g. 1 charge every 150 ticks).
             New rule parts: WHEN "my projectile hits"; IF "distance to opponent",
             "my projectile is out"; DO "spawn projectile", "teleport".
             Move costs: make a move require and spend a resource.
             Advanced mode: write your own GDScript, appended to the character.

8 EXPORT     Mod doctor lists every problem before you ship.
             EXPORT writes <ModFolder>.zip (Documents/HustleForge by default) and can
             copy it straight into the game's mods folder.
             EXPORT & PLAY also starts the game through Steam.
             After playing, "Read game log" shows only the log lines about YOUR mod.

NEW IN v0.4
-----------
Poser tab (no drawing needed): skeleton posing with IK, keyframes + automatic
         in-betweens, body shape generator, accessory library with swinging capes /
         hair / tails, ready-made looks + RANDOMIZE, pose and animation libraries,
         one-click "Rig ALL base animations", bake to sprites.
Recolor: whole-character colour schemes (Blood, Gold, Toxic, Ocean, Ice, Royal,
         Shadow, Random...), hue / saturation / brightness / spread, per-colour
         picks, keeps the player's white, optional effects, undo. Also in Sprites.
The stick-fighter template is rigged, so a new project can be restyled at once.

NEW IN v0.3
-----------
Moves:   Player input (aim circle / forward half / 8 directions / slider, plus a
         toggle and a choice dropdown) that can steer projectiles, teleports,
         pushes and knockback; "When" filters on effects, spawns, teleports, pushes.
         Requirements (usable only if...), forms, damage scaling with a resource,
         growing costs, hold-to-repeat / charge, cards of a deck.
         Kind "Throw": hold the grabbed opponent frame by frame, release + hit.
         Grab hitboxes "Throws into"; any hitbox "On hit go to" (chains).
         Custom hurtboxes per tick, button icon from a sprite, game flags.
Objects: Projectiles with speed 0 become traps / pages / turrets / delayed
         attacks: wait for the opponent or for activation, max on field, shorter
         life when placed far. Teleport to "my object nearest to the aim point".
Mechanics: Forms (stances with stat changes), decks / hands of moves, action
         panel toggles, new events (move ends / misses / blocked / counter-hit,
         burst, form enter/exit, card drawn, toggles), values (input, hits,
         damage, random 0-99, forms, cards, objects...), actions (set stat, enter
         form, heal opponent, random roll, draw / return cards, activate objects,
         play sound / music...). Random numbers use the game's synced generator.
Sounds:  import your own WAVs (Character tab), used anywhere a sound is picked.
Portrait: choose the animation + frame.

BEGINNER / ADVANCED
-------------------
The toggle in the top bar shows extra fields in orange: raw game properties,
raw cancel category strings, hitlag, multi-hit groups, super freeze, custom code.

SAVING
------
Save writes a project folder: project.json + sprites/<animation>/<frame>_<layer>.png.
Open loads such a folder. The PNGs can also be edited in any other image editor.

INSTALLING A MOD BY HAND
------------------------
Put the exported .zip (do not unzip it) into
  <Steam>/steamapps/common/YourOnlyMoveIsHUSTLE/mods
and enable mods in the game options. Both players need the same zip for online.

HOW IT WORKS (for the curious)
------------------------------
The zip contains: _metadata, ModMain.gd, a CharacterSelect extension calling
addCustomChar, a character scene inheriting the game's BaseChar.tscn, the
SpriteFrames, icons, baked effects, forge.json (mechanics data), two runtime
scripts (ForgeChar.gd / ForgeMove.gd), and precompiled .stex textures in .import/
so the game never has to convert images at load time.
All mechanics run on integers so ghosts, replays and online play stay in sync.
